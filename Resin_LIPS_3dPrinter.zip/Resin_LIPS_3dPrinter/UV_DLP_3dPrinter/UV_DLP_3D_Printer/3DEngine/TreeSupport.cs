﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Engine3D
{
    /// <summary>
    /// This class is a tree-like branching support 
    /// that can attach to an object in multiple places
    /// first pass witll have purely manual editing of this
    /// latter version (hopefully) will generate this automatically
    /// </summary>
    public class TreeSupport: Support
    {

    }
}
