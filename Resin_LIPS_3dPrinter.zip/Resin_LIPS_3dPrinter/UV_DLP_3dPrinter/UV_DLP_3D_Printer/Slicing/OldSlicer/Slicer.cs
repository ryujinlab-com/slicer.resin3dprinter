﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Engine3D;
using System.Collections;
using System.Drawing;
using System.Threading;
using UV_DLP_3D_Printer.Slicing;
using Ionic.Zip;
using System.Drawing.Imaging;
using System.IO;
using UV_DLP_3D_Printer._3DEngine;
using System.Windows.Forms;

namespace UV_DLP_3D_Printer
{
    public class Slicer
    {
        public enum eSliceEvent 
        {
            eSliceStarted,
            eLayerSliced,
            eSliceCompleted,
            eSliceCancelled
        }
        public enum eSliceMethod
        {
            eEvenOdd,
            eNormalCount
        }
        public delegate void SliceEvent(eSliceEvent ev, int layer, int totallayers,SliceFile sf);

        private SliceFile m_sf; // the current file being sliced
        public SliceEvent Slice_Event;
        private Thread m_slicethread;
        private bool m_cancel = false;
        private bool isslicing = false;
        //private ZipFile m_zip; // for storing image slices
        public eSliceMethod m_slicemethod = eSliceMethod.eEvenOdd;

        public Slicer() 
        {
        
        }
        public SliceFile SliceFile 
        {
            get { return m_sf; }
            set { m_sf = value; }
        }
        public bool IsSlicing { get { return isslicing; } }
        public void CancelSlicing() 
        {
            m_cancel = true;
            isslicing = false;
            if (m_sf.m_config.export == true) // if we're exporting image slices
            {
                //if (m_sf.m_config.m_exportopt.ToUpper().Contains("ZIP")) // into the scene cws file
                {
                    SceneFile.Instance().CloseSceneFile(true);
                }
            }
        }
        public void RaiseSliceEvent(eSliceEvent ev, int curlayer, int totallayers)
        {
            if (Slice_Event != null) 
            {
                Slice_Event(ev, curlayer, totallayers, m_sf);
            }
        }
        /// <summary>
        /// This will get the number of slices in the scene from the specified slice config
        /// This uses the Scene object from the app, we slice with individual objects though
        /// </summary>
        /// <param name="sp"></param>
        /// <returns></returns>
        public int GetNumberOfSlices(SliceBuildConfig sp)
        {
            try
            {
                //UVDLPApp.Instance().CalcScene();
                MinMax mm = UVDLPApp.Instance().Engine3D.CalcSceneExtents(); // get the scene min/max
                //int numslices = (int)((UVDLPApp.Instance().Scene.m_max.z - UVDLPApp.Instance().Scene.m_min.z) / sp.ZThick);
                //int numslices = (int)((mm.m_max - mm.m_min) / sp.ZThick);
                int numslices = (int)(mm.m_max / sp.ZThick); // height of whole scene
                return numslices;
            }
            catch (Exception) 
            {
                m_cancel = true;
                return 0;
            }
        }

        // standard scene slicing
        // this function takes the object, the slicing parameters,
        // and the output directory. it generates the object slices
        // and saves them in the directory
        public SliceFile Slice(SliceBuildConfig sp)//, Object3d obj) 
        {
            // create new slice file
            m_sf = new SliceFile(sp);
            m_sf.m_modeltype = Slicing.SliceFile.ModelType.eScene;
            if (sp.export == false)
            {
                m_sf.m_mode = SliceFile.SFMode.eImmediate;
            }
            m_slicethread = new Thread(new ThreadStart(slicefunc));
            m_slicethread.Start();
            isslicing = true;
            return m_sf;
        }

        // slicing of special objects. this is done in immediate mode only. no thread needed
        public SliceFile Slice(SliceBuildConfig sp, SliceFile.ModelType modeltype)//, Object3d obj)
        {
            int numslices = 0;
            string scenename = "";
            switch (modeltype)
            {
                case SliceFile.ModelType.eScene:
                    return Slice(sp);
                    //break;

                case SliceFile.ModelType.eResinTest1:
                    numslices = (int)(7.0 / sp.ZThick);
                    scenename = "Test Model V1";
                    break;
            }

            m_sf = new SliceFile(sp);
            m_sf.m_modeltype = modeltype;
            m_sf.m_mode = SliceFile.SFMode.eImmediate;
            m_sf.NumSlices = numslices;
            SliceStarted(scenename, numslices);
            DebugLogger.Instance().LogRecord("Test model slicing started");
            SliceCompleted(scenename, 0, numslices);
            return m_sf;
        }

        private static Bitmap ReflectX(Bitmap source)
        {
            try
            {
                source.RotateFlip(RotateFlipType.RotateNoneFlipX);
                Bitmap b = new Bitmap(source.Width, source.Height);
                using (Graphics g = Graphics.FromImage((Image)b))
                {
                    g.DrawImage(source, 0, 0, source.Width, source.Height);
                }
                return b;
            }
            catch { return null; }

        }
        private static Bitmap ReflectY(Bitmap source)
        {
            try
            {
                source.RotateFlip(RotateFlipType.RotateNoneFlipY);
                Bitmap b = new Bitmap(source.Width, source.Height);
                using (Graphics g = Graphics.FromImage((Image)b))
                {
                    g.DrawImage(source, 0, 0, source.Width, source.Height);
                }
                return b;
            }
            catch { return null; }

        }
        private static Bitmap ResizeImage(Bitmap imgToResize, Size size)
        {
            try
            {
                Bitmap b = new Bitmap(size.Width, size.Height);
                using (Graphics g = Graphics.FromImage((Image)b))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.DrawImage(imgToResize, 0, 0, size.Width, size.Height);
                }
                return b;
            }
            catch { return null; }
        }

        private static SliceBuildConfig m_saved = new SliceBuildConfig();
        /// <summary>
        /// This get slice immediate is currently for previewing only
        /// </summary>
        /// <param name="curz"></param>
        /// <returns></returns>
        public Slice GetSliceImmediate(float curz)
        {
            try
            {
                SliceBuildConfig sbf = new SliceBuildConfig(m_sf.m_config); // save it
                Slice sl = new Slice();//create a new slice
                sl.m_segments = new List<PolyLine3d>();
                foreach (Object3d obj in UVDLPApp.Instance().Engine3D.m_objects)
                {
                    if (curz >= obj.m_min.z && curz <= obj.m_max.z) // only slice from the bottom to the top of the objects
                    {
                        List<Polygon> lstply = GetZPolys(obj, curz);//get a list of polygons at this slice z height that potentially intersect
                        List<PolyLine3d> lstintersections = GetZIntersections(lstply, curz);//iterate through all the polygons and generate x/y line segments at this 3d z level                        
                        sl.m_segments.AddRange(lstintersections);// Set the list of intersections                         
                    }
                }

                return sl;
            }
            catch (Exception ex)
            {
                string s = ex.StackTrace;
                DebugLogger.Instance().LogRecord(ex.Message);
                return null;
            }        
        
        }
         
        /// <summary>
        /// This function will immediately return a bitmap slice at the specified Z-Level
        /// </summary>
        /// <param name="zlev"></param>
        /// <returns></returns>
        public Bitmap SliceImmediate(float curz) 
        {
            try
            {
                //first take care of scaling up the output bitmap paramters size, so we can re-sample later
                double scaler = 1.5; // specify the scale factor
                m_saved.CopyFrom(m_sf.m_config);// save the orginal
                if (m_sf.m_config.antialiasing == true)
                {
                    scaler = m_sf.m_config.aaval;                    
                    m_sf.m_config.dpmmX *= scaler;
                    m_sf.m_config.dpmmY *= scaler;
                    m_sf.m_config.xres = (int)(scaler * m_sf.m_config.xres);
                    m_sf.m_config.yres = (int)(scaler * m_sf.m_config.yres);
                }
                SliceBuildConfig sbf = new SliceBuildConfig(m_sf.m_config); // save it
                
                Bitmap bmp = new Bitmap(m_sf.m_config.xres, m_sf.m_config.yres); // create a new bitmap on a per-slice basis                    
                Graphics graph = Graphics.FromImage(bmp);
                graph.Clear(UVDLPApp.Instance().m_appconfig.m_backgroundcolor);//clear the image for rendering

                //convert all to 2d lines
                Bitmap savebm = null;
                // check for cancelation

                foreach (Object3d obj in UVDLPApp.Instance().Engine3D.m_objects)
                {
                    savebm = bmp; // need to set this here in case it's not rendered
                    if (curz >= obj.m_min.z && curz <= obj.m_max.z) // only slice from the bottom to the top of the objects
                    {
                        List<Polygon> lstply = GetZPolys(obj, curz);//get a list of polygons at this slice z height that potentially intersect
                        List<PolyLine3d> lstintersections = GetZIntersections(lstply, curz);//iterate through all the polygons and generate x/y line segments at this 3d z level
                        Slice sl = new Slice();//create a new slice
                        sl.m_segments = lstintersections;// Set the list of intersections 
                        sl.RenderSlice(m_sf.m_config, ref bmp);
                        savebm = bmp;
                    }
                }

                if (m_sf.m_config.antialiasing == true) // we're using anti-aliasing here, so resize the image
                {
                    savebm = ResizeImage(bmp,new Size(m_saved.xres,m_saved.yres));
                }
                if (m_sf.m_config.m_flipX == true)
                {
                    savebm = ReflectX(savebm);
                }
                if (m_sf.m_config.m_flipY == true)
                {
                    savebm = ReflectY(savebm);
                }
                //restore the original size
                m_sf.m_config.CopyFrom(m_saved);
                return savebm;
            }
            catch (Exception ex)
            {
                string s = ex.StackTrace;
                DebugLogger.Instance().LogError(ex);
                return null;
            }        
                        
        }

        private void slicefunc()
        {
            try
            {
                MinMax mm = UVDLPApp.Instance().Engine3D.CalcSceneExtents();
                int numslices = (int)((mm.m_max) / m_sf.m_config.ZThick);
                float curz = 0; // start at Wz0               
                int c = 0;
                string scenename = UVDLPApp.Instance().SceneFileName;
                // a little housework here...
                foreach (Object3d obj in UVDLPApp.Instance().Engine3D.m_objects)
                {
                    obj.CalcMinMaxes();
                }

                m_sf.NumSlices = numslices;
                SliceStarted(scenename, numslices);
                DebugLogger.Instance().LogRecord("Slicing started");

                if (m_sf.m_config.export == false)
                {
                    // if we're not actually exporting slices right now, then 
                    // raise the completed event and exit
                    SliceCompleted(scenename, 0, numslices);
                    //m_sf.m_config.CopyFrom(m_saved);
                    isslicing = false;
                    return; // exit slicing, nothing more to do...
                }
                // if we're actually exporting something here, iterate through slices
                for (c = 0; c < numslices; c++)
                {
                    Bitmap savebm = SliceImmediate(curz);
                    if (m_cancel || (savebm == null))
                    {
                        isslicing = false;
                        m_cancel = false;
                        //restore the original sizes 
                        //m_sf.m_config.CopyFrom(m_saved);
                        RaiseSliceEvent(eSliceEvent.eSliceCancelled, c, numslices);
                        return;
                    }
                    curz += (float)m_sf.m_config.ZThick;// move the slice for the next layer
                    //raise an event to say we've finished a slice
                    LayerSliced(scenename, c, numslices, savebm);
                }
                // restore the original
                m_sf.m_config.CopyFrom(m_saved);
                SliceCompleted(scenename, c, numslices);
                DebugLogger.Instance().LogRecord("Slicing Completed");
                isslicing = false;

            }
            catch (Exception ex)
            {
                string s = ex.StackTrace;
                DebugLogger.Instance().LogRecord(ex.Message);
                //RaiseSliceEvent(eSliceEvent.eSliceCancelled,0,0);
                m_cancel = true;
            }
        }

        private void oldslicefunc()
        {
            try
            {
                //first take care of scaling up the output bitmap paramters size, so we can re-sample later
                double scaler = 1.5; // specify the scale factor
                m_saved.CopyFrom(m_sf.m_config); // save the original
                if (m_sf.m_config.antialiasing == true)
                {
                    scaler = m_sf.m_config.aaval;
                    //  scale them up.
                    m_sf.m_config.dpmmX *= scaler;
                    m_sf.m_config.dpmmY *= scaler;
                    m_sf.m_config.xres = (int)(m_sf.m_config.xres * scaler);
                    m_sf.m_config.yres = (int)(m_sf.m_config.yres * scaler);

                }
                else
                {
                    scaler = 1.0; // no scaling
                }

                MinMax mm = UVDLPApp.Instance().Engine3D.CalcSceneExtents();
                int numslices = (int)((mm.m_max) / m_sf.m_config.ZThick);
                float curz = 0; // start at Wz0               
                int c = 0;
                string scenename = UVDLPApp.Instance().SceneFileName;
                // a little housework here...
                foreach (Object3d obj in UVDLPApp.Instance().Engine3D.m_objects)
                {
                    obj.CalcMinMaxes();
                }

                m_sf.NumSlices = numslices;
                SliceStarted(scenename, numslices);
                DebugLogger.Instance().LogRecord("Slicing started");

                if (m_sf.m_config.export == false)
                {
                    // if we're not actually exporting slices right now, then 
                    // raise the completed event and exit
                    SliceCompleted(scenename, 0, numslices);
                    m_sf.m_config.CopyFrom(m_saved);
                    isslicing = false;
                    return; // exit slicing, nothing more to do...
                }
                // if we're actually exporting something here, iterate through slices
                for (c = 0; c < numslices; c++)
                {
                    Bitmap bmp = new Bitmap(m_sf.m_config.xres, m_sf.m_config.yres); // create a new bitmap on a per-slice basis
                    //clear the image for rendering
                    Graphics graph = Graphics.FromImage(bmp);
                    graph.Clear(UVDLPApp.Instance().m_appconfig.m_backgroundcolor);

                    //convert all to 2d lines
                    Bitmap savebm = null;
                    // check for cancelation
                    if (m_cancel)
                    {
                        isslicing = false;
                        m_cancel = false;
                        //restore the original sizes 
                        m_sf.m_config.CopyFrom(m_saved);
                        RaiseSliceEvent(eSliceEvent.eSliceCancelled, c, numslices);
                        return;
                    }

                    foreach (Object3d obj in UVDLPApp.Instance().Engine3D.m_objects)
                    {
                        savebm = bmp; // need to set this here in case it's not rendered
                        if (curz >= obj.m_min.z && curz <= obj.m_max.z) // only slice from the bottom to the top of the objects
                        {
                            //obj.ClearCached();
                            List<Polygon> lstply = GetZPolys(obj, curz);//get a list of polygons at this slice z height that potentially intersect
                            List<PolyLine3d> lstintersections = GetZIntersections(lstply, curz);//iterate through all the polygons and generate x/y line segments at this 3d z level

                            Slice sl = new Slice();//create a new slice
                            sl.m_segments = lstintersections;// Set the list of intersections 
                            // m_sf.m_slices.Add(sl);// add the slice to slicefile        
                            // now render the slice into the scaled, pre-allocated bitmap
                            sl.RenderSlice(m_sf.m_config, ref bmp);
                            savebm = bmp;
                        }
                    }

                    if (m_sf.m_config.antialiasing == true) // we're using anti-aliasing here, so resize the image
                    {
                        savebm = ResizeImage(bmp, new Size(m_saved.xres, m_saved.yres));
                    }
                    if (m_sf.m_config.m_flipX == true)
                    {
                        savebm = ReflectX(savebm);
                    }
                    if (m_sf.m_config.m_flipY == true)
                    {
                        savebm = ReflectY(savebm);
                    }
                    curz += (float)m_sf.m_config.ZThick;// move the slice for the next layer
                    //raise an event to say we've finished a slice
                    LayerSliced(scenename, c, numslices, savebm);
                }
                // restore the original
                m_sf.m_config.CopyFrom(m_saved);
                SliceCompleted(scenename, c, numslices);
                DebugLogger.Instance().LogRecord("Slicing Completed");
                isslicing = false;

            }
            catch (Exception ex)
            {
                string s = ex.StackTrace;
                DebugLogger.Instance().LogRecord(ex.Message);
                //RaiseSliceEvent(eSliceEvent.eSliceCancelled,0,0);
                m_cancel = true;
            }
        }

        private void SliceStarted(string scenename, int numslices) 
        {
            if ( m_sf.m_config.export == true) // if we're exporting
            {
                //exporting to cws file
                //get the name oif the scene file
                if (UVDLPApp.Instance().SceneFileName.Length == 0) 
                {
                    MessageBox.Show("Please Save the Scene First Before Exporting Slices");
                    CancelSlicing();
                    return;
                }
                if (UVDLPApp.Instance().SceneFileName.Length != 0) // check again to make sure we've really got a name
                {
                    //remove all the previous images first
                    SceneFile.Instance().RemoveExistingSlices(UVDLPApp.Instance().SceneFileName);
                    //remove any slice profile in the scene file
                    SceneFile.Instance().RemoveExistingSliceProfile(UVDLPApp.Instance().SceneFileName);
                    //create a memory stream to hold the slicing profile in memory
                    MemoryStream ms = new MemoryStream();
                    //serialize the slciing profile into the memory stream
                    string sliceprofilename = Path.GetFileNameWithoutExtension(UVDLPApp.Instance().m_buildparms.m_filename) + ".slicing";
                    UVDLPApp.Instance().m_buildparms.Save(ms, sliceprofilename);
                    ms.Seek(0, SeekOrigin.Begin); // rewind
                    //save the stream to the scene cws zip file
                    SceneFile.Instance().AddSliceProfileToFile(UVDLPApp.Instance().SceneFileName, ms, sliceprofilename);
                    // if we've saved this scene before, then we can save the images into it. Open it up for add
                    SceneFile.Instance().OpenSceneFile(UVDLPApp.Instance().SceneFileName);
                }
                else 
                {
                    //no name? cancel slicing
                    CancelSlicing();
                }
            }
            RaiseSliceEvent(eSliceEvent.eSliceStarted, 0, numslices);
        }

        // currently, this will save both into a zip file and into a subdirectory
        private void LayerSliced(string scenename, int layer, int numslices, Bitmap bmp) 
        {
            string path;
            try
            {
                // if (m_buildparms.exportimages)
                {
                    // get the model name
                    String modelname = scenename;
                    // strip off the file extension
                    path = SliceFile.GetSliceFilePath(modelname);
                    String imname = Path.GetFileNameWithoutExtension(modelname) + String.Format("{0:0000}", layer) + ".png";
                    String imagename = path + UVDLPApp.m_pathsep + imname;
                    //if (m_sf.m_config.m_exportopt.ToUpper().Contains("ZIP"))
                    {
                        // create a memory stream for this to save into
                        MemoryStream ms = new MemoryStream();
                        bmp.Save(ms, ImageFormat.Png);
                        ms.Seek(0, SeekOrigin.Begin); // seek back to beginning
                        if (!m_cancel) // if we're not in the process of cancelling
                        {
                            SceneFile.Instance().AddSlice(ms, imname);
                        }
                    }                   
                    RaiseSliceEvent(eSliceEvent.eLayerSliced, layer, numslices);
                }
            }
            catch (Exception ex) 
            {
                string s = ex.StackTrace;
                DebugLogger.Instance().LogError(ex.Message);
            }
        }
        private void SliceCompleted(string scenename, int layer, int numslices) 
        {
            if (m_sf.m_config.export == true) // if we're exporting image slices
            {
                //if (m_sf.m_config.m_exportopt.ToUpper().Contains("ZIP"))
                {
                    SceneFile.Instance().CloseSceneFile(false);
                }
            }
            RaiseSliceEvent(eSliceEvent.eSliceCompleted, layer, numslices);
        }

        /*
         This function takes in a list of polygons along with a z height.
         * What is returns is an ArrayList of 3d line segments. These line segments correspond
         * to the intersection of a plane through the polygons. Each polygon may return 0 or 1 line intersections 
         * on the 2d XY plane
         * I beleive I can determine the winding order (inside or outside facing), based off of the polygon normal
         */
        public List<PolyLine3d> GetZIntersections(List<Polygon> polys, float zcur) 
        {
            try
            {
                List<PolyLine3d> lstlines = new List<PolyLine3d>();
                foreach (Polygon poly in polys) 
                {
                    PolyLine3d s3d = poly.IntersectZPlane(zcur);
                    if (s3d != null) 
                    {
                        lstlines.Add(s3d);
                    }
                }
                return lstlines;
            }
            catch (Exception) 
            {
                return null;
            }
        }

        /*
         Return a list of polygons that intersect at this zlevel
         */
        public List<Polygon> GetZPolys(Object3d obj, double zlev) 
        {
            List<Polygon> lst = new List<Polygon>();
            try
            {
                if (zlev >= obj.m_min.z && zlev <= obj.m_max.z)
                {
                    foreach (Polygon p in obj.m_lstpolys)
                    {
                        //check and see if current z level is between any of the polygons z coords
                        //MinMax mm = p.CalcMinMax();
                        if (p.m_minmax.InRange(zlev))
                        {
                            lst.Add(p);
                        }
                    }
                }                
            }
            catch (Exception ex) 
            {
                DebugLogger.Instance().LogError(ex.Message);
            }
            return lst;
        }

        // this function generates slices for a test object needed for layer calibration
        public Bitmap GetTestModelV1Slice(int layer)
        {
            float pw = 50; // test pattern width (user parameter?)
            float ph = 20; // test pattern height
            float xdp = (float)m_sf.m_config.dpmmX;
            float ydp = (float)m_sf.m_config.dpmmY;
            int bw = m_sf.m_config.xres;
            int bh = m_sf.m_config.yres;
            // make sure the test pattern is not too wide
            if ((pw * xdp) > (0.9f * bw))
            {
                pw = (0.9f * bw) / xdp;
                ph = (0.9f * bh) / ydp;
            }
            Bitmap bmp = new Bitmap(bw, bh); // create a new bitmap on a per-slice basis                    
            Graphics graph = Graphics.FromImage(bmp);
            graph.Clear(UVDLPApp.Instance().m_appconfig.m_backgroundcolor); //clear the image for rendering
            Brush br = new SolidBrush(UVDLPApp.Instance().m_appconfig.m_foregroundcolor);
            int testlayer = m_sf.NumSlices - 10;
            if (layer < 10)
            {
                // generate a 54 * 24 mm base
                float w = xdp * (pw + 4);
                float h = ydp * (ph + 4);
                float x = (bw - w) / 2;
                float y = (bh - h) / 2;
                graph.FillRectangle(br, x, y, w, h);
            }
            else 
            {
                // generate support walls
                float w = xdp * pw;
                float h = ydp * ph;
                float x = (bw - w) / 2;
                float y = (bh - h) / 2;
                float step = w / 5;
                // vertical bars
                for (int i = 0; i < 6; i++)
                {
                    float x1 = x + i * step - xdp;
                    graph.FillRectangle(br, x1, y, 2 * xdp, h);
                }
                // center horizontal bar
                float y1 = y + h / 2 - ydp;
                graph.FillRectangle(br, x, y1, w, 2 * xdp);
            }
            if ((layer >= testlayer) && (layer < m_sf.NumSlices))
            {
                float w = xdp * pw;
                float h = ydp * ph;
                float x = (bw - w) / 2;
                float y = (bh - h) / 2;
                float stepx = w / 5;
                float stepy = h / 2;
                for (int i = 0; i <= layer - testlayer; i++)
                {
                    float x1 = x + stepx * (i % 5);
                    float y1 = y + stepy * (i / 5);
                    graph.FillRectangle(br, x1, y1, stepx, stepy);
                }
            }
            return bmp;
        }

    }
}
